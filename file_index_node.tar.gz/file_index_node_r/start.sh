#! /bin/bash
service_name=if_node
sudo service $service_name start
